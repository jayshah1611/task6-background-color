
var mycolor = ["red", "blue", "black", "purple", "orange"];
var i = 0;

function changeColor() {
    i++;
    if (i > 4) {
        i = 0;
    }

    if (i == 0) {
        document.body.style.background = mycolor[i];

    } else if (i == 1) {
        document.body.style.background = mycolor[i];

    } else if (i == 2) {
        document.body.style.background = mycolor[i];

    } else if (i == 3) {
        document.body.style.background = mycolor[i];

    } else if (i == 4) {
        document.body.style.background = mycolor[i];

    }
}

